package in.org.weatherapp.view.fragment;

import androidx.fragment.app.Fragment;

public class BaseFragment extends Fragment {
}
