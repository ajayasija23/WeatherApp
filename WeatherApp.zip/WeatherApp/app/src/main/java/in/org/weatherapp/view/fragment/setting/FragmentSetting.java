package in.org.weatherapp.view.fragment.setting;


import in.org.weatherapp.view.fragment.BaseFragment;

public class FragmentSetting extends BaseFragment {


}
