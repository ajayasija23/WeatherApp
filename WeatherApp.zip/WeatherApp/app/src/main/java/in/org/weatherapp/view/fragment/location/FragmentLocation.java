package in.org.weatherapp.view.fragment.location;


import in.org.weatherapp.view.fragment.BaseFragment;

public class FragmentLocation extends BaseFragment {
}
