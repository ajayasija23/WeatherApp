package in.org.weatherapp.view;

import android.app.Application;

public class MyApp extends Application {

    public static double latitude;
    public static double longitude;
    public static String cityName="";
}
