package in.org.weatherapp.view.utils;

public class Constants {
    public static String TAG_HOME="HOME";
    public static String TAG_MANAGE_LOCATION="MANAGE_LOCATIONS";
    public static String TAG_SETTINGS="SETTINGS";
}
